// #define DEBUG_TRIGGERS

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UIElements;

public class PlayerDetector : MonoBehaviour
{
  [SerializeField]
  UnityEvent<Vector2> onSpotPlayer;
  [SerializeField]
  UnityEvent<Vector2> onSeePlayer;
  [SerializeField]
  UnityEvent<Vector2> onLostPlayer;

  [SerializeField]
  private Transform[] rays = null;

  Vector2? knownPlayerPosition = null;

  void Awake()
  {
    Debug.Assert(rays != null);
  }

  void OnDrawGizmos()
  {
    var origin = transform.position;
    foreach (var ray in this.rays)
    {
      Gizmos.DrawLine(origin, ray.transform.position);
    }
  }

  void OnTriggerStay2D(Collider2D other)
  {
#if DEBUG_TRIGGERS
    Debug.LogFormat("Player detection still sees something {0}", other.gameObject);
#endif
    TryToDetectPlayerAndInvokeEvent(other);
  }

  void OnTriggerEnter2D(Collider2D other)
  {
#if DEBUG_TRIGGERS
    Debug.LogFormat("Player detection spotted something {0}", other.gameObject);
#endif
    TryToDetectPlayerAndInvokeEvent(other);
  }

  void OnTriggerExit2D(Collider2D other)
  {
#if DEBUG_TRIGGERS
    Debug.LogFormat("Player detection lost track of something {0}", other.gameObject);
#endif
    TryToDetectPlayerAndInvokeEvent(other);
  }

  void TryToDetectPlayerAndInvokeEvent(Collider2D other)
  {
    var player = other.GetComponentInParent<PlayerController>();
    var seePlayer = player != null && !player.IsDead;

#if DEBUG_TRIGGERS
    Debug.LogFormat("See player {0}", seePlayer);
#endif
    if (!seePlayer) return;

    var raycastHit = RaycastForPlayer();
    var seePlayerNow = raycastHit != null;
    var sawPlayerLastFrame = this.knownPlayerPosition != null;
    if (seePlayerNow && sawPlayerLastFrame)
    {
      this.knownPlayerPosition = raycastHit.Value;
      onSeePlayer.Invoke(this.knownPlayerPosition.Value);
    }
    else if (seePlayerNow && !sawPlayerLastFrame)
    {
      this.knownPlayerPosition = raycastHit.Value;
      onSpotPlayer.Invoke(this.knownPlayerPosition.Value);
    }
    else if (!seePlayerNow && sawPlayerLastFrame)
    {
      onLostPlayer.Invoke(this.knownPlayerPosition.Value);
      this.knownPlayerPosition = null;
    }
  }

  Vector2? RaycastForPlayer()
  {
    var origin = transform.position;
    foreach (var ray in this.rays)
    {
      var rayEnd = ray.transform.position;
      var rayDirection = rayEnd - origin;
      var rayDistance = rayDirection.magnitude;

      int layerMask = 1 << Layers.PlayerDetectorPlayer | 1 << Layers.Walls;
      var raycastHit = Physics2D.Raycast(origin, rayDirection, rayDistance, layerMask);
      if (raycastHit.collider != null)
      {
#if DEBUG_TRIGGERS
        Debug.LogFormat("Raycast hit {0}", raycastHit.collider.gameObject);
#endif
        var player = raycastHit.collider.GetComponentInParent<PlayerController>();
        if (player != null)
        {
#if DEBUG_TRIGGERS
          Debug.Log("See ya!");
#endif
          return raycastHit.rigidbody.position;
        }
      }
      else
      {
#if DEBUG_TRIGGERS
        Debug.LogFormat("Raycast hit nothing.");
#endif
      }
    }
    return null;
  }
}
