#define DEBUG_PLAYER_DETECTION

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
  public enum State
  {
    OnGuard,
    Unconscious,
    Following,
    Searching,
  }

  [SerializeField]
  Waypoint[] waypoints = new Waypoint[0];
  [SerializeField]
  float movementSpeed = 2.0f;
  [SerializeField]
  float followingSpeed = 3.0f;
  [SerializeField]
  private Rigidbody2D rigidBody;
  [SerializeField]
  private SpriteRenderer sprite;
  [SerializeField]
  private Animator animator;
  [SerializeField]
  private PlayerDetector playerDetector;

  [SerializeField]
  private float unconsciousDuration = 1.0f;
  [SerializeField]
  private float searchPhaseDuration = 1.0f;
  [SerializeField]
  private int numSearchPhases = 8;


  private float unconsciousStartTime = Mathf.NegativeInfinity;
  private float lastSearchPhaseTime = Mathf.NegativeInfinity;

  private Nullable<Vector2> lastKnownPlayerPosition = null;
  private int searchPhase = 0;

  private static readonly Vector2[] searchPhases = new Vector2[] { Vector2.down, Vector2.left, Vector2.up, Vector2.right };

  private State state
  {
    get { return _state; }
    set
    {
      Debug.LogFormat("New enemy state {0}", value);
      switch (value)
      {
        case State.Unconscious:
          this.unconsciousStartTime = Time.fixedTime;
          animator.SetBool("EnemyDazed", true);
          SetCollidersActive(false);
          break;
        case State.OnGuard:
          animator.SetBool("EnemyDazed", false);
          SetCollidersActive(true);
          break;
        default:
          SetCollidersActive(true);
          break;
      }
      _state = value;
    }
  }
  private State _state;

  int currentWaypoint = 0;
  float currentWaypointArrival = 0.0f;

  void SetCollidersActive(bool state)
  {
    foreach (var collider in GetComponentsInChildren<Collider2D>())
    {
      collider.enabled = state;
    }
  }

  void Awake()
  {
    Debug.Assert(this.rigidBody != null);
    Debug.Assert(waypoints != null);
    Debug.Assert(waypoints.Length > 0);
    Debug.Assert(animator != null);
  }

  void Start()
  {
    this.currentWaypoint = 0;
    this.currentWaypointArrival = Time.time;
    this.state = State.OnGuard;
  }

  void FixedUpdate()
  {
    // Reset the velocity in case the guard got pushed.
    this.rigidBody.velocity = Vector2.zero;
    switch (this.state)
    {
      case State.OnGuard:
        GuardFixedUpdate();
        break;
      case State.Unconscious:
        // Do nothing while unconscious.
        if (Time.fixedTime >= this.unconsciousStartTime + this.unconsciousDuration)
        {
          state = State.OnGuard;
        }
        break;
      case State.Searching:
        SearchingFixedUpdate();
        break;
      case State.Following:
        FollowingFixedUpdate();
        break;
    }
  }

  void FollowingFixedUpdate()
  {
    Debug.Assert(lastKnownPlayerPosition != null);
    FixedUpdateMoveTowards(this.lastKnownPlayerPosition.Value, followingSpeed);
  }

  void SearchingFixedUpdate()
  {
    if (Time.fixedTime > this.lastSearchPhaseTime + this.searchPhaseDuration)
    {
      this.searchPhase++;
      this.lastSearchPhaseTime = Time.fixedTime;
    }
    if (this.searchPhase >= this.numSearchPhases)
    {
      this.state = State.OnGuard;
      this.searchPhase = 0;
      return;
    }
    var currentPhase = searchPhases[this.searchPhase % searchPhases.Length];
    LookTowards(currentPhase);
  }

  void GuardFixedUpdate()
  {
    var waypoint = this.waypoints[this.currentWaypoint];
    var timeSinceArrival = Time.fixedTime - currentWaypointArrival;

#if false
    Debug.LogFormat("Moving towards waypoint {0}", waypoints);
    Debug.LogFormat("Time since arrival = {0}, wait time = {1}", timeSinceArrival, waypoint.waitTime);
#endif

    // Do nothing if we need to wait.
    if (timeSinceArrival < waypoint.waitTime)
    {
      animator.SetBool("EnemyWalking", false);
      return;
    }

    FixedUpdateMoveTowards(waypoint.transform.position, movementSpeed);
  }

  void FixedUpdateMoveTowards(Vector2 destination, float speed)
  {
    animator.SetBool("EnemyWalking", true);
    animator.speed = speed / this.movementSpeed;

    // Move towards the waypoint.
    var currentPosition = this.rigidBody.position;

    var toWaypoint = destination - currentPosition;
    var distanceToWaypoint = toWaypoint.magnitude;
    var frameDistance = speed * Time.fixedDeltaTime;

    var distanceToMove = Mathf.Min(distanceToWaypoint, frameDistance);
#if false
    Debug.LogFormat(
        "distanceToMove = {0}, frameDistance = {1}, distanceToWaypoint = {2}",
        ∆distanceToMove, frameDistance, distanceToWaypoint);
#endif
    this.rigidBody.MovePosition(currentPosition + distanceToMove * toWaypoint.normalized);

    if (toWaypoint.x < 0)
    {
      this.sprite.flipX = false;
    }
    else if (toWaypoint.x > 0)
    {
      this.sprite.flipX = true;
    }

    if (distanceToWaypoint < 0.01f)
    {
      this.currentWaypoint++;
      if (this.currentWaypoint >= this.waypoints.Length) this.currentWaypoint = 0;
      this.currentWaypointArrival = Time.fixedTime;
    }
    else
    {
      LookTowards(toWaypoint);
    }
  }

  void LookTowards(Vector2 direction)
  {
    playerDetector.transform.localRotation = Quaternion.LookRotation(Vector3.forward, new Vector3(direction.y, direction.x));
    // TODO: Set up animation.
  }

  public void OnSpotPlayer(Vector2 playerPosition)
  {
#if DEBUG_PLAYER_DETECTION
    Debug.LogFormat("Spotted the player at {0}", playerPosition);
#endif
    if (this.state == State.Unconscious) return;

    this.lastKnownPlayerPosition = playerPosition;
    this.state = State.Following;
  }

  public void OnSeePlayer(Vector2 playerPosition)
  {
#if DEBUG_PLAYER_DETECTION
    Debug.LogFormat("Still see player at {0}", playerPosition);
#endif
    if (this.state == State.Unconscious) return;

    Debug.AssertFormat(this.state == State.Following, "Expected State.Following, found {0}", this.state);
    this.lastKnownPlayerPosition = playerPosition;
  }

  public void OnLostPlayer(Vector2 playerPosition)
  {
#if DEBUG_PLAYER_DETECTION
    Debug.LogFormat("Lost the player at {0}", playerPosition);
#endif
    if (this.state == State.Unconscious) return;

    Debug.AssertFormat(this.state == State.Following, "Expected State.Following, found {0}", this.state);
    this.lastKnownPlayerPosition = playerPosition;
    this.state = State.Searching;
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    var bannana = other.GetComponent<BannanaController>();
    if (bannana != null && bannana.state == BannanaController.State.Peeled)
    {
#if false
      Debug.Log("Ouch!");
#endif
      state = State.Unconscious;
      Destroy(bannana.gameObject);
    }
  }

  void OnDrawGizmos()
  {
    for (int i = 0; i < waypoints.Length; ++i)
    {
      var current = waypoints[i].transform.position;
      var next = waypoints[(i + 1) % waypoints.Length].transform.position;
      Gizmos.DrawCube(current, 0.1f * Vector3.one);
      Gizmos.DrawLine(current, next);
    }
  }
}
