using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorBehaviour : MonoBehaviour
{
     public bool DoorState
  {
    get { return this.anim.GetBool("Door_Open"); }
    set
    {
      this.anim.SetBool("Door_Open", value);
      this.collider.enabled = !value;
    }
  }
  Animator anim;
  Collider2D collider;

  public void Build(bool state)
  {
    Debug.LogFormat("Set door state {0}", state);
    this.DoorState = state;
  }

  void Awake()
  {
    anim = GetComponent<Animator>();
    collider = GetComponent<Collider2D>();
  }

}
