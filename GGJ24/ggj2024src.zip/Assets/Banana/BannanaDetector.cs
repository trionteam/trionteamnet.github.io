using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BannanaDetector : MonoBehaviour
{
  public bool HasBannana()
  {
    var filter = new ContactFilter2D();
    filter.layerMask = 1 << Layers.Objects;
    var list = new List<Collider2D>();
    int numCollisions = Physics2D.OverlapCollider(GetComponent<Collider2D>(), filter, list);
#if false
    Debug.LogFormat("Found {0} items", numCollisions);
#endif
    foreach (var item in list)
    {
      if (item.GetComponent<BannanaController>() != null)
      {
        return true;
      }
    }
    return false;
  }
}
