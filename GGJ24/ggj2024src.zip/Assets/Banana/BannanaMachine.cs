using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BannanaMachine : MonoBehaviour
{
  [SerializeField]
  private BannanaDetector bannanaDetector = null;
  [SerializeField]
  private Transform bannanaDropPoint = null;
  [SerializeField]
  private GameObject bannanaPrefab = null;

  void Awake()
  {
    Debug.Assert(bannanaPrefab != null);
    Debug.Assert(bannanaDropPoint != null);
    Debug.Assert(bannanaDetector != null);
  }

  public void DropBannana()
  {
    if (bannanaDetector.HasBannana()) 
    {
      Debug.Log("Bannana machine can't drop, there's already a bannana");
      return;
    }
    Instantiate(bannanaPrefab, bannanaDropPoint.position, Quaternion.identity);
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    Debug.LogFormat("Bannana machine triggered by {0}", other.gameObject);
    if (other.gameObject.layer == Layers.Teeth)
    {
      DropBannana();
    }
  }
}
