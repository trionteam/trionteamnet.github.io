using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BannanaController : MonoBehaviour
{
  public enum State
  {
    Full,
    Peeled
  }

  [SerializeField]
  public State state;

  [SerializeField]
  private GameObject peeledPrefab;

  void Awake()
  {
    Debug.Assert(state == State.Peeled || peeledPrefab != null);
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    bool isTeeth = other.GetComponent<ToothController>() != null;
    if (isTeeth && this.state == State.Full)
    {
      Destroy(gameObject);
      Instantiate(peeledPrefab, this.transform.position, Quaternion.identity);
    }
  }
}
