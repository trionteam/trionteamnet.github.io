using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LeverInteractionCollider : MonoBehaviour
{
  [SerializeField]
  UnityEvent triggered;

  void OnTriggerEnter2D(Collider2D other)
  {
    Debug.LogFormat("Lever triggered by {0}", other);
    if (other.gameObject.layer != Layers.Teeth
        && other.gameObject.layer != Layers.PlayerDetectorPlayer)
    {
      return;
    }
    if (triggered != null) triggered.Invoke();
  }
}
