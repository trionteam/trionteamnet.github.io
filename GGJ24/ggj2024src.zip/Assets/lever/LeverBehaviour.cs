using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UIElements;

public class LeverBehaviour : MonoBehaviour
{
  public UnityEvent<bool> onTriggered;

  public bool LeverState
  {
    get { return this.anim.GetBool("LeverState"); }
    set
    {
      this.anim.SetBool("LeverState", value);
      this.onTriggered.Invoke(value);
    }
  }
  Animator anim;

  void Awake()
  {
    anim = GetComponent<Animator>();

    Debug.Assert(anim != null);
  }

  // Start is called before the first frame update
  void Start()
  {
    LeverState = false;
  }

  public void Trigger()
  {
    LeverState = !LeverState;
  }
}
