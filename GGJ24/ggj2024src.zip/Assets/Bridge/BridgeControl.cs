using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BridgeControl : MonoBehaviour
{
  public bool BridgeState
  {
    get { return this.anim.GetBool("BridgeState"); }
    set
    {
      this.anim.SetBool("BridgeState", value);
      this.collider.enabled = !value;
    }
  }
  Animator anim;
  Collider2D collider;

  public void Build(bool state)
  {
    Debug.LogFormat("Set bridge state {0}", state);
    this.BridgeState = state;
  }

  void Awake()
  {
    anim = GetComponent<Animator>();
    collider = GetComponent<Collider2D>();
  }

  void Start()
  {

  }
}
