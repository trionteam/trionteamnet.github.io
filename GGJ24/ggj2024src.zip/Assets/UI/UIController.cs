using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
  [SerializeField]
  PlayerController player;
  [SerializeField]
  TMPro.TextMeshProUGUI bannanaCounterUI;
  [SerializeField]
  private GameObject GameOverGraphics;

  bool gameOverActivated = false;

  void Awake()
  {
    Debug.Assert(player != null);
    GameOverGraphics.SetActive(false);
  }

  IEnumerator GameOverWithDelay(float delay)
  {
    yield return new WaitForSeconds(delay);
    GameOver();
  }

  // Update is called once per frame
  void Update()
  {
    if (Input.GetKeyDown(KeyCode.Escape)) Application.Quit();

    bannanaCounterUI.text = string.Format("{0}", player.bannanaCounter);
    if (!gameOverActivated && player.IsDead)
    {
      gameOverActivated = true;
      StartCoroutine(GameOverWithDelay(3));
    }
  }

  public void GameOver()
  {
    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
  }

}
