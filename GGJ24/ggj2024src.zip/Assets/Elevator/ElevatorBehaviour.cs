using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ElevatorBehaviour : MonoBehaviour
{
  [SerializeField]
  GameObject ElevatorDoor;

  [SerializeField]
  string nextSceneName;

  [SerializeField]
  bool startOpen = true;

  // public bool IsOpen { get { return this.ElevatorDoor.Get}}

  public void OpenElevator()
  {

    this.ElevatorDoor.SetActive(false);
  }

  public void CloseElevator()
  {
    this.ElevatorDoor.SetActive(true);
  }

  public void ToggleElevator()
  {
    if (this.ElevatorDoor.active)
    {
      OpenElevator();
    }
    else
    {
      CloseElevator();
    }
  }

  void Start()
  {
    if (startOpen)
      OpenElevator();
    else
      CloseElevator();
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    var player = other.GetComponent<PlayerController>();
    if (player != null)
    {
      CloseElevator();
      StartCoroutine(LoadNextScene());
    }
  }

  IEnumerator LoadNextScene()
  {
    yield return new WaitForSeconds(3);
    if (!string.IsNullOrEmpty(nextSceneName))
    {
      SceneManager.LoadScene(nextSceneName);
    }
  }
}
