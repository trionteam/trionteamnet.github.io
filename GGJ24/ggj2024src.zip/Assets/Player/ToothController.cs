using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using UnityEngine;


public class ToothController : MonoBehaviour
{
  [SerializeField]
  private float movementSpeed = 3.0f;

  [SerializeField]
  private float maxDistanceFromPlayer = 3.0f;
  [SerializeField]
  private SpriteRenderer spriteRenderer = null;

  PlayerController player;

  Vector2 movement;

  Action onDestroy;

  [SerializeField]
  private AudioSource audioSource;

  public void Launch(PlayerController player, Vector3 position, Vector2 orientation, Action onDestroy)
  {
    this.player = player;
    this.transform.position = position;
    this.movement = movementSpeed * orientation;
    this.onDestroy = onDestroy;

    if (orientation.x > 0)
    {
      this.spriteRenderer.flipX = true;
    }
  }

  void FixedUpdate()
  {
    Vector3 delta = Time.fixedDeltaTime * this.movement;
    this.transform.position = this.transform.position + delta;

    var distanceFromPlayer = (this.transform.position - this.player.transform.position).magnitude;
    if (distanceFromPlayer > maxDistanceFromPlayer)
    {
      Destroy(gameObject);
    }
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    Debug.LogFormat("Teeth triggered by {0}!", other.gameObject);
    var bannana = other.GetComponent<BannanaController>();
    if (bannana != null && bannana.state == BannanaController.State.Peeled) return;
    if (bannana != null) Destroy(gameObject);

    if (other.gameObject.layer != Layers.Objects)
    {
      Destroy(gameObject);
    }
  }

  void OnDestroy()
  {
    if (this.onDestroy != null) onDestroy();
  }
}
