using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Analytics;
using UnityEngine.Events;

public class PlayerController : MonoBehaviour
{
  [SerializeField]
  private float movementSpeed = 1.0f;

  [SerializeField]
  private float minMovementMagnitude = 0.7f;

  [SerializeField]
  private Rigidbody2D rigidBody = null;
  [SerializeField]
  private SpriteRenderer sprite = null;

  [SerializeField]
  private GameObject teethPrefab = null;

  [SerializeField]
  private GameObject bannanaPeelPrefab = null;

  [SerializeField]
  public int bannanaCounter = 0;

  [SerializeField]
  private int peeledBannanaCounter = 0;
  [SerializeField]
  private float peeledBannanaDropDistance = 0.8f;

  [SerializeField]
  private Animator animator;
  [SerializeField]
  private UnityEvent onPlayerDied;


  private bool death;
  public bool IsDead { get { return this.death; } }

  Vector2 orientation = Vector2.left;

  ToothController teeth = null;

  [SerializeField]
  GameObject interactionUI = null;

  void Awake()
  {
    Debug.Assert(bannanaPeelPrefab != null);
    Debug.Assert(teethPrefab != null);
    Debug.Assert(rigidBody != null);
    Debug.Assert(sprite != null);
  }

  void FixedUpdate()
  {
    this.rigidBody.velocity = Vector2.zero;

    if (this.death) return;
    float dx = Input.GetAxis("Horizontal");
    float dy = Input.GetAxis("Vertical");
    if (interactionUI != null && interactionUI.activeInHierarchy)
    {
      // Do not walk while talking.
      dx = 0.0f;
      dy = 0.0f;
    }

    Vector2 movement = new Vector2(dx, dy);
    if (movement.magnitude > minMovementMagnitude)
    {
      rigidBody.MovePosition(rigidBody.position + movementSpeed * Time.fixedDeltaTime * movement);

      if (dx < 0)
      {
        // sprite.flipX = false;
        animator.SetBool("Player_Walking_Left", true);
        animator.SetBool("Player_Walking_Right", false);
      }
      else if (dx > 0)
      {
        // sprite.flipX = true;
        animator.SetBool("Player_Walking_Right", true);
        animator.SetBool("Player_Walking_Left", false);
      }

    }
    else
    {
      animator.SetBool("Player_Walking_Left", false);
      animator.SetBool("Player_Walking_Right", false);
    }

    if (movement != Vector2.zero)
    {
      orientation = movement.normalized;
    }
  }

  void OnCollisionEnter2D(Collision2D collision)
  {
    var enemy = collision.gameObject.GetComponent<EnemyController>();
    if (enemy != null)
    {
      Die();
    }
  }

  void OnTriggerEnter2D(Collider2D other)
  {
#if false
    Debug.Log("Player triggered by");
#endif
    var bannana = other.GetComponent<BannanaController>();
    if (bannana != null)
    {
      if (bannana.state == BannanaController.State.Full)
      {
        // Pick up bannana.
        this.bannanaCounter++;
        Destroy(bannana.gameObject);
      }
      else
      {
        Die();
      }
    }

    bool isLava = other.gameObject.layer == 4;
    if (isLava)
    {
      Die();
    }
  }

  void Update()
  {
    if (interactionUI != null && interactionUI.activeInHierarchy) return;
    if (Input.GetButtonDown("Fire2"))
    {
      LaunchTeeth();
    }
    if (Input.GetButtonDown("Fire1"))
    {
      DropBannanaPeel();
    }
  }

  void LaunchTeeth()
  {
    if (this.teeth != null) return;
    this.teeth = Instantiate(teethPrefab).GetComponent<ToothController>();
    this.teeth.Launch(this, this.transform.position, this.orientation, () =>
    {
      this.teeth = null;
    });
  }

  void DropBannanaPeel()
  {
    if (this.bannanaCounter > 0)
    {
      --this.bannanaCounter;
      var peelPosition = this.rigidBody.position + this.peeledBannanaDropDistance * this.orientation.normalized;
      Instantiate(this.bannanaPeelPrefab, peelPosition, Quaternion.identity);
    }
  }

  void Die()
  {
    death = true;
    foreach (var collider in GetComponentsInChildren<Collider2D>())
    {
      collider.enabled = false;
    }
    animator.SetBool("Player_Dazed", true);
    onPlayerDied.Invoke();
  }
}