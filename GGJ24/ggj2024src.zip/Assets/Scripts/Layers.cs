using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Layers
{
  public static readonly int Default = 0;
  public static readonly int Water = 4;
  public static readonly int Player = 6;
  public static readonly int Walls = 7;
  public static readonly int Teeth = 8;
  public static readonly int Objects = 9;
  public static readonly int PlayerDetectorPlayer = 10;
  public static readonly int Enemy = 11;
  public static readonly int PlayerDetectorEnemy = 12;
  public static readonly int ActionableByTeeth = 13;
  public static readonly int ActionableByPlayer = 14;
}
