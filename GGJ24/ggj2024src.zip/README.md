# Till the last laugh

This is our contribution to the Global Game Jam 2024.

## About the game

You take the role of a poor clown thrown into a dungeon by the evil m~~e~~imes.

## How to play

Use a gamepad to play the game. Move the stick to walk around, press the A/B
(X/square) buttons to launch the teeth or drop banana peels.

## How to build

The game was built with Unity 2022.3.18f1.

All the assets we created are included in this package. To build and run the
game, you also need TextMeshPro from Unity and [Dialogue system from
HeneGames](https://assetstore.unity.com/packages/tools/gui/dialogue-system-248969).

## License

The source code of the game is available under the [Creative Commons
Attribution-NonCommercial-ShareAlike 4.0 International
license](https://creativecommons.org/licenses/by-nc-sa/4.0/).
